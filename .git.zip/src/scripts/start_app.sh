#!/bin/bash

echo "Start Digital Dish... Please enjoy!"
# Print the current directory
current_dir=$(pwd)
echo "Current directory: $current_dir"
# Start app from here
python3 myapp/main.py