#!/bin/bash

# begin of the scripts that will intialise and run myapp

chmod +x scripts/python_check.sh
./scripts/python_check.sh